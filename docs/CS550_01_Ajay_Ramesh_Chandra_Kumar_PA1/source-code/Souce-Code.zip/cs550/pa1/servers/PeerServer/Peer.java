/**
 * File Name : Peer.java
 * Description : peer interface file
 * @authors : Ajay Ramesh and Chandra Kumar Basavaraju
 * version : 1.0
 * @date : 01/28/2017
 */
package cs550.pa1.servers.PeerServer;

/**
 * Created by Ajay on 1/26/17.
 */
public interface Peer {

    void init();
}
